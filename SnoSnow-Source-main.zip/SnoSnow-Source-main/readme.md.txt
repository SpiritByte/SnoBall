Dependencies:

-Pygame

-pyinstaller (For building to .exe) (optional)